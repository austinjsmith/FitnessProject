create table if not exists Meals (
    mealname TEXT, 
    maincalorie INTEGER ,  
    fats INTEGER, 
    carbs INTEGER, 
    proteins INTEGER
);

